<?php $__env->startSection('content'); ?>

<div id="body">	
	<div class="container">
		<div class="col-md-12 content-middle">
			<div class="contact-form wow fadeInUp animated" data-wow-delay=".1s">
				<h3><b>About US</b></h3>
				<br>
				<h4><i>Updated November, 2016</i></h4>
				<p>This Site has been made for educational purposes only by students of RMIT University towards the completion of COSC 2650 - CPT331 - Programming Project 1</p>
				<p>If you're wondering what CLEVO stands for here is the full disclosure:</p>
				<ul>
					<li><b>C</b> - Carlo</li>
					<li><b>L</b> - Lucas</li>
					<li><b>E</b> - Evan</li>
					<li><b>V</b> - Vio</li>
					<li><b>O</b> - Ocal</li>
					<li><b>CLEVO</b> - Project Contributors</li>
				</ul>
				<p><i>CLEVO Team</i></p>	
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>