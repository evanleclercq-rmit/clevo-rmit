@extends('layouts.app')

@section('content')


<div id="body">	
	<div class="container">
		<div class="col-md-12 content-middle">
			<div style="text-align: center" class="contact-form wow fadeInUp animated" data-wow-delay=".1s">
				<h1><br><br><b>This page was not found.</b></h1><br>
				<h2>Please check the address and try again.</h2>
			</div>
		</div>
	</div>
</div>

@endsection
