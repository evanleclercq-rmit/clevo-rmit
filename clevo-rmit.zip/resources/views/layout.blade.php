<!DOCTYPE html>

<html>

    <head>
        <title>The Budding Investor</title>
        <meta charset='utf-8'/>
        @yield ('head')
        
    </head>
    
    <body>
        
        @yield ('banner')
        @yield ('content')
        @yield ('footer')
        
    </body>
        
</html>